package utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Properties;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.PageLoadStrategy;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.github.javafaker.Faker;

import cucumber.api.Scenario;

public class TestBase{
	    
	public static WebDriver driver= null;
	public static Properties prop=null;
	public static FileInputStream fis = null;
	public static String CurrentDir =System.getProperty("user.dir");
	public static String path = "/BDDFramework.properties";
    public static String uname = null;
	public static String key = null;
	public static String SFticketno=null;
	public static String ticketno;
	public static String Docid=null;
	public static String fei_client_Fname=null;
	public static String fei_client_Lname=null;
	public static String Notes = null;
	public static String Tasktitle = null;
	public static String Taskstate = null;
	public static String Taskdesc = null;
	public static File file = null;
//	public static String TESTDATA_SHEET_PATH="src/test/resources/Externalfiles/TestData.xlsx";
	public static String TESTDATA_SHEET_PATH=null;
	public static String CONFIG_SHEET_PATH="src/test/resources/Externalfiles/Config.xlsx";
	public static String configsheetname = null;
	public static XSSFWorkbook book=null;
	public static XSSFSheet sheet =null;
	public static String Testcaseid=null;
	public static String FEIhomepage=null;
	public static String Testcasedescription=null;
	public static Faker datagenerate = new Faker();
	public static String Client_firstname =null;
	public static String Client_lastname =null;
	public static String Accountnumber =null;
	public static String Taxid =null;
	public static String primary_rep_code=null;
	public static String Clientprospectpage = null;
	public static String Pdfdoc= CurrentDir + "\\src\\test\\resources\\Externalfiles\\dummy.pdf";
//	public static String Pdfdoc="W:\\MphasisQA\\Advisor Portal - FO\\2019\\Regression Test Case\\FEIAutomationLatest\\FEI_Latest\\BDDFramework\\src\\test\\resources\\Externalfiles\\dummy.pdf";
	public static String Ticketno=null;
    public static String clientmanagewind=null;
    public static String docupacewindow=null;
    public static String Clientaddedwin=null;
    public static int columnno=0;
    public static String shortname=null;
	public TestBase() {
		try {
			
			prop= new Properties();
			fis = new FileInputStream(CurrentDir+path);
			prop.load(fis);
			}
		catch(FileNotFoundException e) {
			e.printStackTrace();
		}catch (IOException e) {
			e.printStackTrace();
		}
		 }

	public WebDriver selectBrowser(String server,String browser) throws Throwable  {
			
			if (server.equalsIgnoreCase(Server.LOCAL.name())) {
				
				if (browser.equalsIgnoreCase(Browsers.CHROME.name())) {
					System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir") + "/src/test/resources/drivers/chromedriver_87.exe");
					System.setProperty("webdriver.chrome.silentOutput","true");
					ChromeOptions options = new ChromeOptions();
					if(config("Config","Headless","Value").equalsIgnoreCase("TRUE")) {
					options.addArguments("--headless"); }
					DesiredCapabilities capabilities = new DesiredCapabilities();
					capabilities.setCapability(ChromeOptions.CAPABILITY, options);
					options.merge(capabilities);
					driver = new ChromeDriver(options);
					driver.manage().window().maximize();
				} else if (browser.equalsIgnoreCase(Browsers.FIREFOX.name())) {
					System.setProperty("webdriver.gecko.driver", System.getProperty("user.dir") + "/src/test/resources/drivers/geckodriver.exe");
					driver = new FirefoxDriver();
				}
						
			}
			else if (server.equalsIgnoreCase(Server.SAUCE.name())) {
				String sauceusername = config("Config","SAUCE_Username","Value");
				String saucekey = config("Config","SAUCE_Key","Value");
				DesiredCapabilities capabilities = new DesiredCapabilities();				  
		    	capabilities.setCapability("browserName", browser);		    	
		        capabilities.setCapability("platform", "Windows 10");
		        capabilities.setCapability("version", "79.0");
		        capabilities.setCapability("build", "Equipt regression");
		        capabilities.setCapability("name", "3-cross-browser");
		         //this.driver = new RemoteWebDriver(new URL("http://avincent:715c984a-0993-497e-b308-64ac750a0180@ondemand.saucelabs.com:80/wd/hub"),capabilities);
		        this.driver = new RemoteWebDriver(new URL("http://"+sauceusername+":"+saucekey+"@ondemand.saucelabs.com:80/wd/hub"),capabilities);
		      				
			}
		
		    return driver;
	}
	public void select_input() throws Throwable
	{
		if(config("Config","Environment","Value").equalsIgnoreCase("QA")) {
			configsheetname = "QA_Data";
			TESTDATA_SHEET_PATH="src/test/resources/Externalfiles/TestData_QA.xlsx";
		}
		if(config("Config","Environment","Value").equalsIgnoreCase("PRODUCTION")) {
			configsheetname = "PROD_Data";
			TESTDATA_SHEET_PATH="src/test/resources/Externalfiles/TestData_PROD.xlsx";
		}
	}
	public void getfeaturefiledetails (Scenario scenario) throws Throwable {
		String scenarioname = scenario.getName();
		String[] arrayScenarioName = scenarioname.split("-");
		Testcaseid = arrayScenarioName[0];
		System.out.println("Testcaseid: " +Testcaseid);
		Testcasedescription = arrayScenarioName[1];
	    String rawFeatureName = scenario.getId().split(";")[0].replace("-"," ");
	    if(rawFeatureName.contains("salesforcecase")) {
	    	excelWrite("Cases",Testcaseid,"CaseNo","CaseNo not generated");
	    }
	    else if(rawFeatureName.contains("servicenettickets")) {
	    	excelWrite("ServicenetTickets",Testcaseid,"TicketNo","Ticket not generated");
	    }
	    else if(rawFeatureName.contains("clientprospects")) {
	    	excelWrite("ClientProspects",Testcaseid,"SSNID","SSNID not generated");
			excelWrite("ClientProspects",Testcaseid,"Account No","AccountNo not generated");
	    }
	  
	}
	public static String getUserName(String username) throws IOException {
 		prop=new Properties();
 		fis=new FileInputStream(CurrentDir+path);
 		prop.load(fis);
 		uname = prop.getProperty(username);
 		return uname;
 	}

 	public static String getPwd(String password) throws IOException {
 		prop=new Properties();
 		fis=new FileInputStream(CurrentDir+path);
 		prop.load(fis);
 		key = prop.getProperty(password);
 		return key;
 	}
 	
 	public String config(String sheetname,String testcaseid, String header) throws IOException {
        String value = null;;
        try {
            FileInputStream fis = new FileInputStream(CONFIG_SHEET_PATH);
            book = new XSSFWorkbook(fis);
            sheet = book.getSheet(sheetname);
            int lastRowNum = sheet.getLastRowNum();
            int lastCellNum = sheet.getRow(0).getLastCellNum();      
            for (int i = 0; i < lastRowNum; i++) {
                for (int j = 1; j < lastCellNum; j++) {      
                    Map<String, Map<String, String>> excelmap = new HashMap<String, Map<String, String>>();
                    LinkedHashMap<String, String> map = new LinkedHashMap<String, String>();
                    map.put(sheet.getRow(0).getCell(j).toString(), sheet.getRow(i + 1).getCell(j).toString());
                    excelmap.put(sheet.getRow(i + 1).getCell(0).toString(), map);
                    if (excelmap.containsKey(testcaseid)) {
                        Map<String, String> w = excelmap.get(testcaseid);
                        if (map.containsKey(header)) {
                            value = w.get(header).toString();
                        }}}}
        } catch (NullPointerException E) {
        }
        return value;
    }
 	public String excelRead(String sheetname,String testcaseid, String header) throws IOException {
        String value = null;;
        try {
            FileInputStream fis = new FileInputStream(TESTDATA_SHEET_PATH);
            book = new XSSFWorkbook(fis);
            sheet = book.getSheet(sheetname);
            int lastRowNum = sheet.getLastRowNum();
            int lastCellNum = sheet.getRow(0).getLastCellNum();      
            for (int i = 0; i < lastRowNum; i++) {
                for (int j = 1; j < lastCellNum; j++) {      
                    Map<String, Map<String, String>> excelmap = new HashMap<String, Map<String, String>>();
                    LinkedHashMap<String, String> map = new LinkedHashMap<String, String>();
                    map.put(sheet.getRow(0).getCell(j).toString(), sheet.getRow(i + 1).getCell(j).toString());
                    excelmap.put(sheet.getRow(i + 1).getCell(0).toString(), map);
                    if (excelmap.containsKey(testcaseid)) {
                        Map<String, String> w = excelmap.get(testcaseid);
                        if (map.containsKey(header)) {
                            value = w.get(header).toString();
                        }}}}
        } catch (NullPointerException E) {
        }
        return value;
    }
 	public int returncolumno(String sheetname, String header) throws Throwable{
		File file = new File(TESTDATA_SHEET_PATH);
        FileInputStream fis = new FileInputStream(file);
        XSSFWorkbook workbook = new XSSFWorkbook(fis);
        XSSFSheet sheet = workbook.getSheet(sheetname);
        XSSFRow row = sheet.getRow(0);
		for (int cn=0; cn<row.getLastCellNum(); cn++) {
		   Cell c = row.getCell(cn);
		      String text = c.getStringCellValue();
		      if (header.equals(text)){    
	                columnno = c.getColumnIndex();
		      }
		   }
		return columnno;
		
	}
	
	public void excelWrite(String sheetname, String testcaseid,String header,String value) throws Throwable {
        File file = new File(TESTDATA_SHEET_PATH);
        FileInputStream fis = new FileInputStream(file);
        XSSFWorkbook workbook = new XSSFWorkbook(fis);
        XSSFSheet sheet = workbook.getSheet(sheetname);
        int sheetnoOfColumns = sheet.getRow(0).getPhysicalNumberOfCells();
        int lastRowNum = sheet.getLastRowNum();      
        	for (int i = 0; i < lastRowNum; i++) {
            Map<Map<String, String>, String> excelmap = new HashMap<Map<String, String>, String>();
            LinkedHashMap<String, String> map = new LinkedHashMap<String, String>();
            map.put(sheet.getRow(0).getCell(0).toString(), sheet.getRow(i + 1).getCell(0).toString());  
            if (map.containsValue(testcaseid)) {
                excelmap.put(map, value);
                String w = map.get("TestCase ID");
                Map<String, String> fin = new HashMap<String, String>();
                fin.put(w, value);
                Row row = sheet.getRow(i + 1);
            //    createheader(sheetname, header);
               Cell createcell = row.createCell(returncolumno(sheetname, header));
                createcell.setCellValue(value);
            
        	}
        }
        FileOutputStream fileOut = new FileOutputStream(TESTDATA_SHEET_PATH);
        workbook.write(fileOut);
    //  workbook.close();
        fis.close();
        fileOut.close();
    }
	 public String ReadTestcaseid()
	    {
	    	String s= Testcaseid;
			String[] arrayte = s.split("_");
			String no = String.format("%03d",(Integer.parseInt(arrayte[1])-1));
			String Readtestcaseid = "TC_"+no;
			System.out.println("ReadTestcaseid"+Readtestcaseid);
			return Readtestcaseid;
	    }

	
 	
	}	
					
		
	


