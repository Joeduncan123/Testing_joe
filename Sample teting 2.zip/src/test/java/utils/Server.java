package utils;

public enum Server {
	
	LOCAL,
	SAUCE

}
