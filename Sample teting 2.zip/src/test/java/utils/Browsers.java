package utils;


public enum Browsers {
	
	CHROME,
	FIREFOX
	
}
