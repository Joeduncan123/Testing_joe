package utils;

import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.math.BigDecimal;
import java.math.RoundingMode;
import org.openqa.selenium.JavascriptExecutor;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Set;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;


public class TestUtils extends TestBase {
	
	
	String browserLoadStatus;
	 public List<String> browserTabs;
	
	public void navigation_to_window() throws Throwable{
	   Set <String> st= driver.getWindowHandles();
       for(String windowhandle:st)
       driver.switchTo().window(windowhandle);	 
	}
	public void explicit_wait_elementvisibility(WebElement element) {
		WebDriverWait wait = new WebDriverWait(driver,40);
		wait.until(ExpectedConditions.visibilityOf(element));

	}
	public void explicit_wait_elementvisibility(List<WebElement> list) {
		WebDriverWait wait = new WebDriverWait(driver,40);
		wait.until(ExpectedConditions.visibilityOfAllElements(list));

	}
	public void explicit_wait_title(String title) {
		WebDriverWait wait = new WebDriverWait(driver,40);
		wait.until(ExpectedConditions.titleContains(title));
	}
	
	public void clickandhold(WebElement element){
	    Actions action = new Actions(driver);
	    action.clickAndHold(element).build().perform();	   
	}
	public String integertostring(String value) {
		int values= new BigDecimal(value).setScale(0,RoundingMode.HALF_UP).intValue();
		String svalue= Integer.toString(values);
		return svalue;
	}
	public void select_value(WebElement element, String value) {
		Select select = new Select(element);
		select.selectByVisibleText(value);
		
	}
	
	public void selectElement(List<WebElement> listvalue , String inputvalue ) {
		
		for (WebElement actualvalue : listvalue) {
			if (actualvalue.getText().trim().equalsIgnoreCase(inputvalue)) {
				actualvalue.click();
				break;
			}
		}
		}
	
	    
	    public static String generateRandomDate(String format, String startdate, String enddate) throws Throwable
		  {
		   DateFormat formatter = new SimpleDateFormat(format);
		   Calendar cal=Calendar.getInstance();
		   cal.setTime(formatter.parse(startdate));
		   Long value1 = cal.getTimeInMillis();

		   cal.setTime(formatter.parse(enddate));
		   Long value2 = cal.getTimeInMillis();

		   long value3 = (long)(value1 + Math.random()*(value2 - value1));
		   cal.setTimeInMillis(value3);
		   return formatter.format(cal.getTime());
		     }
	    
	    public void select_date(WebElement element,String value) {
			Select select = new Select(element);
			List<WebElement> list=select.getOptions();
			for(int i=0;i<list.size();i++) {
				if(list.get(i).getText().contains(value)) {
					list.get(i).click();
				}
			}
			
		}
	   public void datepicker(String exceldate, WebElement dateinput,WebElement Yearelement,WebElement Monthelement,List<WebElement> dateelement) throws Throwable {
		   String[] edates = exceldate.split("-");
		   String Date = edates[0];
		   String Month =edates[1];
		   String Year = edates[2];
		   dateinput.click();
		   Thread.sleep(2000);
		   select_date(Yearelement,Year);
		   Thread.sleep(2000);
		   select_date(Monthelement,Month);
		   String datetest = StringUtils.stripStart(Date,"0");
		   for(int i=0;i<dateelement.size();i++) {
			   if(dateelement.get(i).getText().equals(datetest)) {
				   Thread.sleep(2000);
				   dateelement.get(i).click();
			   }
		   }
		   
	   }
	    public void doubleclick(WebElement element){
	    	Actions action = new Actions(driver);
	    	action.doubleClick(element).perform();
	    }
	    public void doubleClickAction(WebElement ele) {
			Actions act = new Actions(driver);
			act.moveToElement(ele).doubleClick(ele).build().perform();
		}
	    public void handle_frame(WebElement frameid){
			driver.switchTo().frame(frameid);
		}

	    public void fileupload(String filelocation) throws Throwable {
			try {
				Thread.sleep(3000);
				StringSelection stringSelection = new StringSelection(filelocation);
				Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
				clipboard.setContents(stringSelection, null);
				Thread.sleep(3000);
				Robot robot = new Robot();
				Thread.sleep(3000);
				robot.keyPress(KeyEvent.VK_CONTROL);
				robot.keyPress(KeyEvent.VK_V);
				robot.keyRelease(KeyEvent.VK_CONTROL);
				Thread.sleep(3000);
				robot.keyPress(KeyEvent.VK_ENTER);
				robot.keyRelease(KeyEvent.VK_ENTER);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	    public void waitForPageLoad() throws InterruptedException{
	    	WebDriverWait wait = new WebDriverWait(driver, 60);
	    	wait.until(new ExpectedCondition<Boolean>() {
	            public Boolean apply(WebDriver wdriver) {
	                return ((JavascriptExecutor) driver).executeScript(
	                    "return document.readyState"
	                ).equals("complete");
	            }
	        });
	    	do{
	    		Thread.sleep(1000);
	    		browserLoadStatus = (String) ((JavascriptExecutor) driver).executeScript("return document.readyState");
	    		System.out.println("browserLoadStatus: "+browserLoadStatus);
	    	}while(!browserLoadStatus.equals("complete"));
	    }
	    
	    public void switchToTab(int tabIndex) throws InterruptedException{
	    	Thread.sleep(4000);
	    	browserTabs = null;
	    	browserTabs = new ArrayList<String>();
	    	browserTabs.addAll(driver.getWindowHandles());
	    	
	    	driver.switchTo().window(browserTabs.get(tabIndex));
	    	Thread.sleep(3000);
	    }


}
