package listeners;
import java.util.concurrent.atomic.AtomicInteger;
import org.testng.IRetryAnalyzer;
import org.testng.ITestResult;
import utils.TestBase;

public class FailedRetry  extends TestBase implements IRetryAnalyzer{
	private static int MAX_RETRY_COUNT = 1;

    AtomicInteger count = new AtomicInteger(MAX_RETRY_COUNT);

    public boolean isRetryAvailable() {
        return (count.intValue() > 0);
    }
    
    @Override
    public boolean retry(ITestResult result) {
        boolean retry = false;
        try {
        if (isRetryAvailable()) {
            retry = true;
            count.decrementAndGet(); 
        }}
        catch(Throwable t)
        {}
        return retry;
    }
}
