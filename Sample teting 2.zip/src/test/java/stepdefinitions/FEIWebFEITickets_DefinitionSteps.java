package stepdefinitions;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import steps.BOLoginPageSteps;
import steps.DocupacePageSteps;
import steps.FEIApplicationPageSteps;
import steps.FEIHomepageSteps;
import steps.FEITicketDetailsSteps;
import steps.FOLoginPageSteps;
import steps.HomePageSteps;
import steps.SalesforceCasePageSteps;
import steps.SalesforceHomePageSteps;
import steps.ServicenetPageSteps;
import steps.ServicenetTicketPageSteps;
import utils.TestBase;

public class FEIWebFEITickets_DefinitionSteps extends TestBase {

	
	ServicenetPageSteps servicenetpagesteps = new ServicenetPageSteps(driver);
	ServicenetTicketPageSteps servicenetticketpagesteps = new ServicenetTicketPageSteps(driver);
	FEIApplicationPageSteps feiapplicationpagesteps = new FEIApplicationPageSteps(driver);
	FEIHomepageSteps feihomepagesteps = new FEIHomepageSteps(driver);
	FEITicketDetailsSteps feiticketdetailstep = new FEITicketDetailsSteps(driver);
	FOLoginPageSteps fologinpagesteps=new FOLoginPageSteps(driver);
	BOLoginPageSteps bologinpagesteps = new BOLoginPageSteps(driver);
	HomePageSteps homepagesteps = new HomePageSteps(driver);
	SalesforceHomePageSteps sfhomepagesteps = new SalesforceHomePageSteps(driver);
	SalesforceCasePageSteps salesforcecasesteps = new SalesforceCasePageSteps(driver);
	DocupacePageSteps docupacepagesteps =new DocupacePageSteps(driver);

	
	@Given("^user is in FEI login page$")
	public void user_is_in_FEI_login_page() throws Throwable {
		feihomepagesteps.select_input();
		System.out.println("url"+config(configsheetname,"FEI_URL","Value"));
		feihomepagesteps.is_the_home_page(config(configsheetname,"FEI_URL","Value"));
	}

	@When("^user create new ticket in FEI$")
	public void user_create_new_ticket_in_FEI() throws Throwable {
		FEIhomepage = driver.getWindowHandle();
		feihomepagesteps.clicknewdropdown();
		feihomepagesteps.find_doc();
		feihomepagesteps.verify_ticket();
	}
	@When("^user enter required details in the tickets$")
	public void user_enter_required_details_in_the_tickets() throws Throwable {
		 feiticketdetailstep.step_getTicketno();
		 feiticketdetailstep.step_enterRequiredDatainticketdetailsPage();
		 feiticketdetailstep.step_getfeiClient_Fname();
		 feiticketdetailstep.step_getfeiClient_Lname();
		 feiticketdetailstep.step_getTicketdocid();
		 	feiticketdetailstep.Exitbtn.click();
			Thread.sleep(1000);
			feiticketdetailstep.step_navigate_to_homepage();
		 
	}

	@When("^Added notes to the created ticket$")
	public void added_notes_to_the_created_ticket() throws Throwable {
		feiticketdetailstep.step_addingnotes(); 
	
	}
	
	@When("^Added task to the created ticket and save the ticket detail$")
	public void added_task_to_the_created_ticket_and_save_the_ticket_detail() throws Throwable {
		feiticketdetailstep.step_addingtasks();	
	}

	@When("^Create notification for the ticket to sent fax and save the ticket details$")
	public void create_notification_for_the_ticket_to_sent_fax_and_save_the_ticket_details() throws Throwable {
		feiticketdetailstep.step_creatingnotification();
		feiticketdetailstep.step_getSFTicketno();
		feiticketdetailstep.Exitbtn.click();
		Thread.sleep(1000);
		feiticketdetailstep.step_navigate_to_homepage();
	}

	@Then("^Verify that Ticket created in FEI can be found in Salesforce as a case successfully$")
	public void verify_that_Ticket_created_in_FEI_can_be_found_in_Salesforce_as_a_case_successfully() throws Throwable {
		feihomepagesteps.select_input();
		System.out.println("url"+config(configsheetname,"BO_URL","Value"));
		bologinpagesteps.is_the_home_page(config(configsheetname,"BO_URL","Value"));
		homepagesteps.click_clientmgmt();
		sfhomepagesteps.click_salesforce();
		Thread.sleep(2000);
		sfhomepagesteps.salesforce_navigation();
		salesforcecasesteps.click_cases();
		Thread.sleep(2000);
		salesforcecasesteps.BOsearch_case();	
	}

	@Then("^Verify that Notes created in FEI are available in salesforce case$")
	public void verify_that_Notes_created_in_FEI_are_available_in_salesforce_case() throws Throwable {
		salesforcecasesteps.verifyCommentsfromFEI(Notes);  
	}

	@Then("^Verify that Task created in FEI are available in salesforce case$")
	public void verify_that_Task_created_in_FEI_are_available_in_salesforce_case() throws Throwable {
		salesforcecasesteps.verifytaskfromFEI(Tasktitle); 
		Thread.sleep(3000);
		driver.close();
		feiticketdetailstep.step_navigate_to_homepage();
		
	}

	@Then("^Verify that FEI ticket is indexed to a Client/Account data, same shows indexed with correct data in Docupace as well$")
	public void verify_that_FEI_ticket_is_indexed_to_a_Client_Account_data_same_shows_indexed_with_correct_data_in_Docupace_as_well() throws Throwable {
		feihomepagesteps.select_input();
		System.out.println("url"+config(configsheetname,"BO_URL","Value"));
		bologinpagesteps.is_the_home_page(config(configsheetname,"BO_URL","Value")); 
		docupacepagesteps.click_documanagement();
		docupacepagesteps.validateFEIDocBasedFEIindexed();
	}
	
}