package pageobjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import utils.TestBase;
import utils.TestUtils;

public class FEIApplicationPage extends TestUtils {
	
	 public FEIApplicationPage(WebDriver driver) {
	    	TestBase.driver=driver;
			PageFactory.initElements(driver, this);
	    }
	
	 @FindBy(xpath="")
	 public WebElement TicketSearch;	 
	
	 @FindBy(xpath="")
	 public WebElement SFTicketNumber;
	 
	 @FindBy(xpath="")
	 public WebElement SearchButton;
	 	
	 @FindBy(xpath="")
	 public WebElement SelectTicket;
	 	
	 @FindBy(xpath="")
	 public WebElement ClickNotes;
	 
	 @FindBy(xpath="")
	 public WebElement VerifyComments;
	 

	 @FindBy(xpath = "")
	 public WebElement tktIdEntryField;

	 @FindBy(xpath = "")
	 public WebElement acceptAlert;
	 

    
      

    
}