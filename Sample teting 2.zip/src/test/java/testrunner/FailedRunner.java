package testrunner;

import cucumber.api.CucumberOptions;

@CucumberOptions(
    monochrome = true,
    features = "@target/rerun.txt", //Cucumber picks the failed scenarios from this file 
    format = {"pretty", "html:target/cucumber-reports/cucumber-pretty",
            "json:target/cucumber-reports/CucumberTestReport.json"}
  )
public class FailedRunner {

}