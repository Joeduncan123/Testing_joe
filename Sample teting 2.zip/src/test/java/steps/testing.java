package steps;

import java.io.FileInputStream;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import utils.TestUtils;

public class testing extends TestUtils {

	public static void main(String[] args) throws Throwable {
		
		testing t = new testing();
		System.out.println(t.validate_values("Rep").equals(t.validate_application("Rep")));
	
	}
		
		public HashMap<String,List<String>> validate_values(String sheetname) throws Throwable {
			HashMap<String,List<String>> map1 = new HashMap<String,List<String>>();
			 FileInputStream fis = new FileInputStream(TESTDATA_SHEET_PATH);
	         book = new XSSFWorkbook(fis);
	         sheet = book.getSheet(sheetname);
	         int lastRowNum = sheet.getLastRowNum();
	         int lastCellNum = sheet.getRow(0).getLastCellNum();      
	         for (int i = 1; i <=lastRowNum; i++) {
	        	 String Writingrep = sheet.getRow(i).getCell(1).toString();
	        	 String Sharingrep = sheet.getRow(i).getCell(2).toString();
	        	 String[] sharelist = Sharingrep.split("\\r?\\n");
	        	 List<String> list = Arrays.asList(sharelist);
	        	 map1.put(Writingrep,list);
	         }
			return map1;
	         }
	         
	        public HashMap<String,List<String>> validate_application(String sheetname) throws Throwable {
	        	HashMap<String,List<String>> map2 = new HashMap<String,List<String>>();
				 FileInputStream fis = new FileInputStream(TESTDATA_SHEET_PATH);
		         book = new XSSFWorkbook(fis);
		         sheet = book.getSheet(sheetname);
		         int lastRowNum = sheet.getLastRowNum();
		         int lastCellNum = sheet.getRow(0).getLastCellNum();      
		         for (int i = 1; i <=lastRowNum; i++) {
		        	 String Writingrep = sheet.getRow(i).getCell(1).toString();
		        	 String Sharingrep = sheet.getRow(i).getCell(2).toString();
		        	 String[] sharelist = Sharingrep.split("\\r?\\n");
		        	 List<String> list = Arrays.asList(sharelist); 
		        	 map2.put(Writingrep,list);
		         }
				return map2;

	}

}
