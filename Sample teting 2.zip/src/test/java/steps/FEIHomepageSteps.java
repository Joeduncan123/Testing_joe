package steps;

import static org.hamcrest.MatcherAssert.assertThat;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import pageobjects.FEIApplicationPage;
import pageobjects.FEIHomePage;

public class FEIHomepageSteps  extends FEIHomePage{
	
	
	public FEIHomepageSteps(WebDriver driver) {
		super(driver);
	}
	  public void is_the_home_page(String URL) {
	    	driver.get(URL);
	    }
	public void clicknewdropdown() throws Throwable {
		waitForPageLoad();
		Newbtn.click();
		imagtkt.click();
		navigation_to_window();
		Thread.sleep(2000);
	}
	public void click_element(WebElement element) {
		element.click();
	}
//	 public WebElement waitFor(WebElement webElement) {
//	        return getRenderedView().waitFor(webElement);
//	    }
	public void find_doc() throws Throwable {
		click_element(finddoc);
		System.out.println("Current working directory in Java : " + Pdfdoc);
		fileupload(Pdfdoc);
		Thread.sleep(3000);
		click_element(createtkt);
		Thread.sleep(10000);
	}
	public void verify_ticket() throws Throwable {
		navigation_to_window();
		waitForPageLoad();
		Thread.sleep(3000);
		assertThat("Ticket Details Page is Launched", ticketdetailstab.getText().equalsIgnoreCase("Ticket Details"));

	}
	
}
