package steps;

import static org.hamcrest.MatcherAssert.assertThat;

import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.List;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;

import pageobjects.FEIHomePage;
import pageobjects.FEITicketDetailsPage;


public class FEITicketDetailsSteps  extends FEITicketDetailsPage{
	JavascriptExecutor jseN = (JavascriptExecutor) driver;
	
	public FEITicketDetailsSteps(WebDriver driver) {
		super(driver);
	}
	public void step_getTicketno() throws Throwable {
		Thread.sleep(3000);
		ticketno = TicketNo.getAttribute("value");
		System.out.println("ticketno --> " + ticketno);
		excelWrite("WebFEITickets",Testcaseid,"TicketNumber",ticketno);
	}
	
		public void step_getTicketdocid() throws Throwable {
			Thread.sleep(3000);
			Docid = feidocid.getAttribute("value");
			System.out.println("Docid --> " + Docid);
			excelWrite("WebFEITickets",Testcaseid,"DocID",Docid);
	}
		
	public void enter_Accountnumber(String Accno)
	{
		explicit_wait_elementvisibility(AccountDataTxt);
		AccountDataTxt.sendKeys(Accno);
	}
		
	public void step_enterRequiredDatainticketdetailsPage() throws Exception {
		enter_Accountnumber(excelRead("WebFEITickets",Testcaseid,"Accountnumber"));
		AccValidateBtn.click();
		Thread.sleep(3000);
		DocTypeBrpDnbtn.click();
		selectElement(DocTypelist,excelRead("WebFEITickets",Testcaseid,"DocClass"));
		Thread.sleep(1000);
		SubDocTypeBrpDnbtn.click();
		Thread.sleep(1000);
		selectElement(SubDocTypelist,excelRead("WebFEITickets",Testcaseid,"DocSubType"));
		GoodOrderbtn.click();
		Thread.sleep(1000);
		selectElement(GoodOrderlist,excelRead("WebFEITickets",Testcaseid,"GoodOrder"));
		Statusbtn.click();
		Thread.sleep(1000);
		selectElement(Statuslist,excelRead("WebFEITickets",Testcaseid,"Status"));
		Clearinghousebtn.click();
		Thread.sleep(1000);
		selectElement(Clearinghouselist,excelRead("WebFEITickets",Testcaseid,"ClearingHouse"));		
		Thread.sleep(2000);
		SaveBtn.click();
		Thread.sleep(2000);
	}
	public void step_navigate_to_homepage() throws Exception
	{
		switchToTab(0);	
	}
	
	public void step_getfeiClient_Fname() throws Throwable {
		Thread.sleep(3000);
		fei_client_Fname = FEIclientFname.getAttribute("value");
		System.out.println("FEI Client first name --> " + fei_client_Fname);
		excelWrite("WebFEITickets",Testcaseid,"FEIClientFname",fei_client_Fname);
}
	public void step_getfeiClient_Lname() throws Throwable {
		Thread.sleep(3000);
		fei_client_Lname = FEIclientLname.getAttribute("value");
		System.out.println("FEI Client last name --> " + fei_client_Lname);
		excelWrite("WebFEITickets",Testcaseid,"FEIClientLname",fei_client_Lname);
}
	
	public void step_addingnotes() throws Exception {
		NotesTab.click();
		Thread.sleep(2000);
		Notes =excelRead("WebFEITickets",Testcaseid,"AddNote");
		NotesTxt.sendKeys(Notes);
		PublishChkbox.click();
		Thread.sleep(2000);
		jseN.executeScript("arguments[0].click()", NoteSaveBtn);
		Thread.sleep(3000);
		Thread.sleep(3000);
		Assert.assertTrue(NotesTextData.getAttribute("value").contains(Notes));
		Thread.sleep(3000);
		SaveBtn.click();
	}
	
	public void step_addingtasks() throws Exception {
		Task.click();
		Thread.sleep(2000);
		Tasktitle =excelRead("WebFEITickets",Testcaseid,"TaskTitle");
		TaskTitle.sendKeys(Tasktitle);
		Taskdesc =excelRead("WebFEITickets",Testcaseid,"TaskDescription");
		TaskDesc.sendKeys(Taskdesc);
		Taskteambtn.click();
		Thread.sleep(1000);
		selectElement(Taskteamlist,excelRead("WebFEITickets",Testcaseid,"TaskTeam"));
		Taskstatusbtn.click();
		Thread.sleep(1000);
		selectElement(Taskstatuslist,excelRead("WebFEITickets",Testcaseid,"TaskStatus"));
		Taskstate =excelRead("WebFEITickets",Testcaseid,"TaskState");
		if(Taskstate.equalsIgnoreCase("Closed"))
			TaskstateClosed.click();
		else
			TaskstateOpen.click();
		TaskstateClosed.click();
		Thread.sleep(2000);
		jseN.executeScript("arguments[0].click()", Tasksavebtn);
		Thread.sleep(2000);
		SaveBtn.click();
	}
	
	public void step_creatingnotification() throws Throwable  {
		
		faxestab.click();
		Thread.sleep(1000);
		CrteNotifibtn.click();
		navigation_to_window();
		waitForPageLoad();
		Tempdropdownbtn.click();
		Thread.sleep(2000);
		selectElement(Tempdropdownlist,excelRead("WebFEITickets",Testcaseid,"FaxTemplate"));
//		Actions action = new Actions(driver); 
//		action.moveToElement(Tempdropmouseover).click().build().perform();
		Repfaxno.clear();
		Repfaxno.sendKeys(excelRead("WebFEITickets",Testcaseid,"RepFax"));
		System.out.println(excelRead("WebFEITickets",Testcaseid,"RepFax"));
		Thread.sleep(1000);
		Repemailid.clear();
		Repemailid.sendKeys(excelRead("WebFEITickets",Testcaseid,"RepEmail"));
		emailid.clear();
		emailid.sendKeys(excelRead("WebFEITickets",Testcaseid,"Email"));
		
		
		Thread.sleep(5000);
		FYICheckbox.click();
		Faxcomments.clear();
		Faxcomments.sendKeys(excelRead("WebFEITickets",Testcaseid,"FaxComments"));
		Thread.sleep(1000);
		jseN.executeScript("arguments[0].click()", SendNotifibtn);
		SaveBtn.click();
	}
	public boolean step_getSFTicketno() throws Throwable {
		int i = 0;
		do {
			driver.navigate().refresh();
			Thread.sleep(10000);
			SFticketno = SFCaseno.getAttribute("value");
			i++;
			Thread.sleep(10000);
		} while ((i <= 60) && SFCaseno.getAttribute("value").equals(""));
		Assert.assertTrue(!SFticketno.isEmpty());
		System.out.println("SF Ticket no"+SFticketno);
		excelWrite("WebFEITickets",Testcaseid,"CaseNumber",SFticketno);
		return true;
	}
	
	
	}
	

